/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ciudad;

/**
 * Interfaz donde se definen los parámetros para iniciar la aplicación 
 * @author Camiku
 */
public interface ParametrosDibujo {
    
    int ANCHO = 100;
    int ALTO = 30;
    int ITERACIONES_CIUDAD = 50;
    int PAUSA_MILISEGUNDOS = 100;
    int NUMERO_SITIOS = 5;
    int CONTENIDO_CARGA = 1234;
    
}
