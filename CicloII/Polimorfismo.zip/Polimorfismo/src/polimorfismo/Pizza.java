/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polimorfismo;

/**
 *
 * @author joag
 */
public class Pizza{
    String[] ingredientes;
    String tipoDePizza;
    
    public void crear(){
        tipoDePizza = "Pepperoni";   
    }
    
    public void crear(String tipoDePizza){
        this.tipoDePizza = tipoDePizza;
    }
    
    public void crear(Integer tipoDePizza){
        switch(tipoDePizza){
            case 1:
                this.tipoDePizza = "Pepperoni";
                break;
            case 2:
                this.tipoDePizza = "Hawaiana";
                break;
        }
    }
}
